package music.wind;

import music.playable;

public class Saxophone implements playable {
	public void play()
	{
		System.out.println("play() from Saxophone");
	}
	

}
