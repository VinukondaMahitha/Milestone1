package music.string;

import music.playable;

public class Veena implements playable
{
	public void play()
	{
		System.out.println("play() from bveena");
	}

}
