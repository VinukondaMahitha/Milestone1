package practice;

public class prac1 {
public static void main(String[] args) {
	String sb="A012upXz";
	StringBuffer s=new StringBuffer();
	for(int i=0;i<sb.length();i++)
	{
		
		if(Character.isUpperCase(sb.charAt(i)))
			s=s.append(Character.toLowerCase(sb.charAt(i)));
		else if(Character.isLowerCase(sb.charAt(i)))
			s=s.append(Character.toUpperCase(sb.charAt(i)));
		else if(Character.isDigit((sb.charAt(i))))
				s=s.append("");
			
	}
	//System.out.println(s);
	s.reverse();
	for(int i=0;i<s.length();i=i+2)
	System.out.print(s.charAt(i));
}
}
