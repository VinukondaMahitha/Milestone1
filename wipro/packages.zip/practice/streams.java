package practice;
import java.io.*;
public class streams {
public static void main(String[] args) throws IOException{
	String s = "";
	int c;
	InputStreamReader ibr=new InputStreamReader(System.in);
	 BufferedReader br = new BufferedReader(ibr);
	 FileReader f=new FileReader("F:\\output.txt");
	 do
	 {
		 c=f.read();
		 System.out.print((char)c);
	 }
	 while((char)c!='$');
	 
	 System.out.println("\nsuccess");
	 f.close();
}
}
