package practice;

public class ThrowTester {

}
