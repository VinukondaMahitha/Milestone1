package practice;

 class InvalidCountryException extends Exception
{
	String InvalidCountryException()
	{
		return("Exception occured");
	}

}
class UserRegistration
{
	public static void main(String[] args) {
		void registerUser(String username,String userCountry)
		{
			if(username.equals("India"))
			{
				System.out.println("User registration done successfully");
			}
			else
			{
				throw new InvalidCountryException("user outside india cannot be registered");
			}
		}
	}
}