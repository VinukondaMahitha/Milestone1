package practice;

abstract class Instrument
{
	abstract void play();
}
class Piano extends Instrument
{
	void play()
	{
		System.out.println("Piano is playing tan tan tan");
	}
}
class Flute extends Instrument
{
	void play()
	{
		System.out.println("Flute is playing toot toot toot");
	}
}
class Guitar extends Instrument
{
	void play()
	{
		System.out.println(" GUtiar is playing tin tin tin");
	}
}
class Test
{
	public static void main(String[] args) {
		Instrument i[]=new Instrument[10];
		for()
		
	}
}