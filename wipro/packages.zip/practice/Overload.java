package practice;
class add
{
	add(int a,int b)
	{
		System.out.println("int:"+(a+b));
	}
}
class sub extends add
{
	 sub(int a,double b)
	{
		 super(10,20);
		System.out.println("double:"+(a+b));
	}
}
public class Overload {
public static void main(String args[])
{
	add a1=new add(10,20);
	sub b=new sub()
}
}
