package practice;

public class Prac {
public static void main(String[] args) {
	String s="Hi HeLlo PlEase";
	String s1=new String();
	for(int i=0;i<s.length();i++)
	{
		if(Character.isUpperCase(s.charAt(i)))
			s1=s1+Character.toLowerCase(s.charAt(i));
		else if(Character.isLowerCase(s.charAt(i)))
			s1=s1+Character.toUpperCase(s.charAt(i));
	}
	System.out.println(s1);
}
}
