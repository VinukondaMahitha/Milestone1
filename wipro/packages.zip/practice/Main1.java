package practice;

public class Main1 {

}
