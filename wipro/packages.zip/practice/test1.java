package practice;

 class div 
{
	void divison(int a,int b) throws ArithmeticException
	{
		int c=a/b;
		System.out.println(c);
	}

}
public class test1
{
	public static void main(String[] args) {
		div d=new div();
		try
		{
		d.divison(4, 0);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
