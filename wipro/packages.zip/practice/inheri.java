package practice;
class A
{
	A()
	{
		System.out.println("A m");
	}
	{
		System.out.println("A Spec");
	}
}
class B extends A
{
	void n()
	{
		System.out.println("B n");
	}
	{
		System.out.println("B spec");
	}
}
public class inheri {
public static void main(String[] args) {
	A s=new A();
	B l=new B();
	//l.m();
l.n();
}
}
